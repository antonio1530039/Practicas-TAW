<?php
	define('SERVER_DB', '127.0.0.1');
	define('USER_DB', 'root');
	define('PASSWORD_DB', '');
	define('DB_NAME', 'practica5');
?>