<!-- Menu de opciones presente en todas las paginas -->
	<link rel="stylesheet" href="views/bootstrap/css/bootstrap.min.css" />
	<link rel="stylesheet" href="views/bootstrap/css/bootstrap-theme.min.css" />
    <script src="views/bootstrap/js/bootstrap.min.js"></script>

<nav class="navbar navbar-expand-lg navbar-light bg-dark" >
	<div class="collapse navbar-collapse" id="navbarNav" >
	<ul class="navbar-nav">
		<li><a  class="nav-link" href="index.php?action=convertidor" style="color:white">Convertidor</a></li>
	</ul>
</div>
</nav>