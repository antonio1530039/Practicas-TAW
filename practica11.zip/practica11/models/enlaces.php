<?php 
//clase encargada de realizar el redireccionamiento de las paginas en base a la variable action en el metodo get
class Paginas{
	
	public function enlacesPaginasModel($enlaces){
		return $module =  "views/modules/convertidor.php";;

	}

}

?>