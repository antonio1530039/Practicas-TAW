    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="view/assets/css/foundation.css" />
    <script src="view/assets/js/vendor/modernizr.js"></script>
<div class="row">
      <div >
        <ul class="right button-group">
          <li><a href="index.php" class="button tiny">Inicio</a></li>
          <li><a href="index.php?action=empleados" class="button tiny">Gestion de Empleados</a></li>
        </ul>
      </div>
    </div>