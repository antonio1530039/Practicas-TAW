<?php
//se termina la sesion destruyendola
session_start();
session_destroy();

?>

<h1>¡Haz salido de la aplicación!</h1>