<?php


	require_once("controller/controller.php");
	require_once("model/enlaces.php");
	require_once("model/crud.php");

	$controller = new MVC();

	$controller->showTemplate();



?>