    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="view/assets/css/foundation.css" />
    <script src="view/assets/js/vendor/modernizr.js"></script>
<div class="row">
      <div >
        <ul class="right button-group">
          <li><a href="index.php" class="button tiny">Inicio</a></li>
          <li><a href="index.php?action=alumnos" class="button tiny">Gestion de Alumnos</a></li>
          <li><a href="index.php?action=maestros" class="button tiny">Gestion de Maestros</a></li>
          <li><a href="index.php?action=carreras" class="button tiny">Gestion de Carreras</a></li>
          <li><a href="index.php?action=tutorias" class="button tiny">Sesion de Tutoria</a></li>
          <li><a href="index.php?action=logout" class="button tiny" style="background-color:red">Log out</a></li>
        </ul>
      </div>
    </div>